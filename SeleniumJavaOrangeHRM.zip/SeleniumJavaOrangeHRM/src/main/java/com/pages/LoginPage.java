package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.qa.util.ConfigReader;


public class LoginPage extends ConfigReader{
	WebDriver driver;	
	
	
	
	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}
	
	
	
	public String getTitle() {
	 String str = driver.getTitle();
	 return str;
	}
	
	public void enterEmail(String username) {
		WebElement email = driver.findElement(By.xpath(prop.getProperty("emailfield")));
		email.sendKeys(username);
		
		
	}
	
	public void enterPassword(String password) {
		WebElement passwordBox = driver.findElement(By.xpath(prop.getProperty("passwordfield")));
		passwordBox.sendKeys(password);
		
		
	}
	
	public void clickLoginbtn() {
		driver.findElement(By.xpath(prop.getProperty("logInBtn"))).click();
	}
	
	
	
	
	public String HomePageTitle()
	{
		String title = driver.findElement(By.xpath("//h6[contains(.,'Dashboard')]")).getText();
		return title;
	}
	
	
	
	
}